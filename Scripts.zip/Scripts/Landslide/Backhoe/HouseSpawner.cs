using UnityEngine;

public class HouseSpawner : MonoBehaviour
{
    [Header("References")]
    public RectTransform houseUI;
    public Canvas targetCanvas;

    [Header("Y Position Settings")]
    [Tooltip("Percentage below screen center (0.05 = 5%)")]
    [Range(0f, 0.5f)]
    public float belowCenterPercent = 0.05f;

    void Start()
    {
        RandomizeHousePosition();
    }

    public void RandomizeHousePosition()
    {
        RectTransform canvasRT = targetCanvas.transform as RectTransform;

        Vector2 canvasSize = canvasRT.rect.size;
        Vector2 houseSize = houseUI.rect.size;

        float yOffset = canvasSize.y * belowCenterPercent;
        float fixedY = -yOffset;

        float minX = -canvasSize.x / 2f + houseSize.x / 2f;
        float maxX =  canvasSize.x / 2f - houseSize.x / 2f;
        float randomX = Random.Range(minX, maxX);

        houseUI.anchoredPosition = new Vector2(randomX, fixedY);
    }
}
