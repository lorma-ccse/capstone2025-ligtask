using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DirtTapHandler : MonoBehaviour, IPointerClickHandler, IGameStarter
{
    [Header("Settings")]
    public float clearRadius = 120f;
    public float backhoeAnimFrameRate = 0.05f;

    [Header("House Padding")]
    public float houseSidePadding = 20f;
    public float houseTopPadding = 20f;
    public float houseBottomPadding = 20f;

    [Header("Timer")]
    public TimerLogic timerLogic;
    public float gameDuration = 30f;

    [Header("References")]
    public Canvas dirtCanvas;
    public RectTransform backhoeParent;
    public Sprite[] backhoeSprites;
    public RectTransform houseUI;

    private bool canTap = false;
    private bool houseFound = false;
    private bool gameEnded = false;
    private bool gameStarted = false;

    private int totalDirtCoveringHouseAtStart;

    public void StartGame()
    {
        if (gameStarted) return;

        gameStarted = true;
        canTap = true;

        totalDirtCoveringHouseAtStart = CountDirtOverlappingHouse();

        if (timerLogic != null)
            timerLogic.StartTimer(gameDuration);

        Debug.Log("DirtTapHandler: Game Started");
    }

    void OnEnable()
    {
        if (timerLogic != null)
            timerLogic.OnTimerFinished += OnTimeUp;
    }

    void OnDisable()
    {
        if (timerLogic != null)
            timerLogic.OnTimerFinished -= OnTimeUp;
    }

    void Update()
    {
        if (!gameStarted || gameEnded) return;

        if (Input.GetMouseButtonDown(0))
            HandleTap(Input.mousePosition);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (!gameStarted || gameEnded) return;

        HandleTap(eventData.position);
    }

    void HandleTap(Vector2 screenPosition)
    {
        if (!canTap || houseFound || gameEnded) return;

        Vector2 backhoePos;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            backhoeParent,
            screenPosition,
            dirtCanvas.worldCamera,
            out backhoePos
        );

        Vector2 dirtPos;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            dirtCanvas.transform as RectTransform,
            screenPosition,
            dirtCanvas.worldCamera,
            out dirtPos
        );

        StartCoroutine(PlayBackhoeAnimation(backhoePos, dirtPos));
    }

    IEnumerator PlayBackhoeAnimation(Vector2 backhoePos, Vector2 dirtPos)
    {
        canTap = false;

        GameObject animGO = new GameObject(
            "BackhoeAnim",
            typeof(RectTransform),
            typeof(CanvasRenderer),
            typeof(Image)
        );

        animGO.transform.SetParent(backhoeParent, false);

        RectTransform rt = animGO.GetComponent<RectTransform>();
        rt.anchoredPosition = backhoePos;
        rt.sizeDelta = backhoeParent.sizeDelta;

        Image img = animGO.GetComponent<Image>();

        foreach (Sprite frame in backhoeSprites)
        {
            img.sprite = frame;
            yield return new WaitForSeconds(backhoeAnimFrameRate);
        }

        Destroy(animGO);

        List<GameObject> toRemove = new List<GameObject>();

        foreach (Transform dirt in dirtCanvas.transform)
        {
            RectTransform dirtRT = dirt.GetComponent<RectTransform>();
            if (Vector2.Distance(dirtRT.anchoredPosition, dirtPos) <= clearRadius)
                toRemove.Add(dirt.gameObject);
        }

        foreach (var d in toRemove)
            Destroy(d);

        if (!houseFound && CountDirtOverlappingHouse() == 0)
        {
            houseFound = true;
            EndGame(true);
        }

        canTap = true;
    }

    void OnTimeUp()
    {
        if (!gameStarted || gameEnded) return;

        Debug.Log("Time's up!");
        EndGame(false);
    }

    void EndGame(bool clearedEarly)
    {
        gameEnded = true;
        canTap = false;

        if (timerLogic != null)
            timerLogic.StopTimer();

        int score;

        if (clearedEarly || totalDirtCoveringHouseAtStart == 0)
        {
            score = 100;
        }
        else
        {
            int remaining = CountDirtOverlappingHouse();
            float ratio = 1f - ((float)remaining / totalDirtCoveringHouseAtStart);
            score = Mathf.RoundToInt(ratio * 100f);
        }

        score = Mathf.Clamp(score, 0, 100);
        bool passed = score >= 60;

        string currentScene = SceneManager.GetActiveScene().name;
        string disaster = "Landslide";
        string difficulty = currentScene.Contains("Hard") ? "Hard" : "Easy";
        int miniGameIndex = 3;

        GameResults.Score = score;
        GameResults.Passed = passed;
        GameResults.DisasterName = disaster;
        GameResults.MiniGameIndex = miniGameIndex;
        GameResults.Difficulty = difficulty;

        DBManager.SaveProgress(disaster, difficulty, miniGameIndex, passed);
        SceneTracker.SetCurrentMiniGame(disaster, difficulty, currentScene);

        SceneManager.LoadScene("TransitionScene");
    }

    int CountDirtOverlappingHouse()
    {
        Rect paddedRect = GetHousePaddedRect();
        int count = 0;

        foreach (Transform dirt in dirtCanvas.transform)
        {
            RectTransform dirtRT = dirt.GetComponent<RectTransform>();
            Vector3[] corners = new Vector3[4];
            dirtRT.GetWorldCorners(corners);

            for (int i = 0; i < 4; i++)
            {
                if (paddedRect.Contains(corners[i]))
                {
                    count++;
                    break;
                }
            }
        }

        return count;
    }

    Rect GetHousePaddedRect()
    {
        Vector3[] corners = new Vector3[4];
        houseUI.GetWorldCorners(corners);

        corners[0].x += houseSidePadding;
        corners[2].x -= houseSidePadding;

        corners[1].y -= houseTopPadding;
        corners[0].y += houseBottomPadding;

        return new Rect(
            corners[0].x,
            corners[0].y,
            corners[2].x - corners[0].x,
            corners[1].y - corners[0].y
        );
    }

    void OnDrawGizmos()
    {
        if (houseUI == null) return;

        Rect padded = GetHousePaddedRect();
        Gizmos.color = Color.yellow;

        Vector3 bl = new Vector3(padded.xMin, padded.yMin, 0f);
        Vector3 tl = new Vector3(padded.xMin, padded.yMax, 0f);
        Vector3 tr = new Vector3(padded.xMax, padded.yMax, 0f);
        Vector3 br = new Vector3(padded.xMax, padded.yMin, 0f);

        Gizmos.DrawLine(bl, tl);
        Gizmos.DrawLine(tl, tr);
        Gizmos.DrawLine(tr, br);
        Gizmos.DrawLine(br, bl);
    }
}
