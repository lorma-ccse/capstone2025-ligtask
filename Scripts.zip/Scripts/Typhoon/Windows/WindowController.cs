using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class WindowController : MonoBehaviour
{
    [Header("UI Elements")]
    public Image xMark; 
    public RectTransform windowRect;
    public float overlapBuffer = 10f;

    private void Start()
    {
        if (xMark != null)
            xMark.enabled = false;
    }

    private void Update()
    {
        Person[] people = Object.FindObjectsByType<Person>(FindObjectsSortMode.None);
        foreach (var person in people)
        {
            RectTransform personRect = person.GetComponent<RectTransform>();
            if (personRect != null && windowRect != null)
            {
                if (IsColliding(personRect, windowRect))
                {
                    FlashX();
                    person.Finish();
                    Destroy(person.gameObject, 0.1f);
                }
            }
        }
    }

    private bool IsColliding(RectTransform person, RectTransform window)
{
    Vector3[] personCorners = new Vector3[4];
    Vector3[] windowCorners = new Vector3[4];
    person.GetWorldCorners(personCorners);
    window.GetWorldCorners(windowCorners);

    bool fromLeft = person.position.x < window.position.x;

    float personEdge = fromLeft ? personCorners[2].x : personCorners[0].x;
    float windowEdge = fromLeft ? windowCorners[0].x : windowCorners[2].x;

    float personHalfWidth = (personCorners[2].x - personCorners[0].x) / 2f;
    float effectiveBuffer = overlapBuffer;

    if (fromLeft)
    {
        return (personEdge - personHalfWidth + effectiveBuffer) >= windowEdge;
    }
    else
    {
        return (personEdge + personHalfWidth - effectiveBuffer) <= windowEdge;
    }
}

    public void FlashX()
    {
        StopAllCoroutines();
        StartCoroutine(FlashRoutine());
    }

    private IEnumerator FlashRoutine()
    {
        if (xMark != null)
        {
            xMark.enabled = true;
            yield return new WaitForSeconds(0.5f);
            xMark.enabled = false;
        }
    }
}
