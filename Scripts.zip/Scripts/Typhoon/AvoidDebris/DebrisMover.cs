using UnityEngine;

public class DebrisMover : MonoBehaviour
{
    private float speed;
    private RectTransform rt;
    private AvoidObstacleManager manager;
    private bool hasReported = false; 
    private bool isPaused = false; 

    private const float speedVariationMin = 0.8f;
    private const float speedVariationMax = 1.2f;

    public void Init(float baseFallSpeed, AvoidObstacleManager mgr, bool randomizeSpeed = false)
    {
        speed = randomizeSpeed 
            ? baseFallSpeed * Random.Range(speedVariationMin, speedVariationMax) 
            : baseFallSpeed;

        manager = mgr;
    }

    private void Awake()
    {
        rt = GetComponent<RectTransform>();
        if (rt == null)
            Debug.LogError($"[DebrisMover] No RectTransform found on {gameObject.name}!");
    }

    void OnEnable()
    {
        SidePanelController.OnPauseStateChanged += HandlePause;
    }

    void OnDisable()
    {
        SidePanelController.OnPauseStateChanged -= HandlePause;
    }

    private void HandlePause(bool paused)
    {
        isPaused = paused;
    }

    void Update()
    {
        if (rt == null) return; 

        if (!isPaused) 
        {
            rt.anchoredPosition += Vector2.down * speed * Time.deltaTime;

            if (manager != null && !hasReported)
            {
                if (manager.PlayerCollides(rt))
                {
                    Debug.Log($"[Collision] Player hit by {gameObject.name} at world pos {rt.position}");
                    manager.OnPlayerHit();
                    hasReported = true;
                    Destroy(gameObject);
                    return;
                }

                if (rt.anchoredPosition.y < -Screen.height / 2f - 200f)
                {
                    manager.OnDebrisDodged();
                    hasReported = true;
                    Destroy(gameObject);
                    return;
                }
            }

            if (rt.anchoredPosition.y < -Screen.height - 500f)
            {
                Destroy(gameObject);
            }
        }
    }
}
