using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class BucketAnimation : MonoBehaviour
{
    [Header("UI Image Target")]
    public Image bucketImage;

    [Header("Sprites")]
    public Sprite idleSprite;
    public Sprite[] startPourFrames;
    public Sprite[] pouringFrames;
    public Sprite[] endPourFrames;

    [Header("Timings")]
    public float frameRate = 0.1f; 

    private Coroutine animationRoutine;
    private bool isPouring = false;

    void Start()
    {
        bucketImage.sprite = idleSprite;
    }

    public void StartPour()
    {
        if (isPouring) return;
        if (animationRoutine != null) StopCoroutine(animationRoutine);
        animationRoutine = StartCoroutine(PourRoutine());
    }

    public void StopPour()
    {
        if (!isPouring) return;
        if (animationRoutine != null) StopCoroutine(animationRoutine);
        animationRoutine = StartCoroutine(EndPourRoutine());
    }

    private IEnumerator PourRoutine()
    {
        isPouring = true;

        for (int i = 0; i < startPourFrames.Length; i++)
        {
            bucketImage.sprite = startPourFrames[i];
            yield return new WaitForSeconds(frameRate);
        }

        while (isPouring)
        {
            for (int i = 0; i < pouringFrames.Length; i++)
            {
                bucketImage.sprite = pouringFrames[i];
                yield return new WaitForSeconds(frameRate);
            }
        }
    }

    private IEnumerator EndPourRoutine()
    {
        isPouring = false;

        for (int i = 0; i < endPourFrames.Length; i++)
        {
            bucketImage.sprite = endPourFrames[i];
            yield return new WaitForSeconds(frameRate);
        }

        bucketImage.sprite = idleSprite;
    }
}
