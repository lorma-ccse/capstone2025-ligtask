using UnityEngine;

[System.Serializable]
public class GoBagItem
{
    public string itemName;     
    public Sprite itemSprite;    
    public bool isNecessary;     
}
