using UnityEngine;
using System.Collections.Generic;

public class GoBagDataTest : MonoBehaviour
{
    public List<GoBagItem> allItems = new List<GoBagItem>();
}
