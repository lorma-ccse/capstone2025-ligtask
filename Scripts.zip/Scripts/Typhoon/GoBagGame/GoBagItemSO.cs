using UnityEngine;

[CreateAssetMenu(fileName = "GoBagItem", menuName = "GoBag/Item")]
public class GoBagItemSO : ScriptableObject
{
    public string itemName;     
    public Sprite itemSprite;  
    public bool isNecessary;     
}
