using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class InGameLogger : MonoBehaviour
{
    [Header("UI Reference")]
    public TextMeshProUGUI logText;

    [Header("Settings")]
    [SerializeField] private int maxLines = 15; 

    private Queue<string> logQueue = new Queue<string>();

    void OnEnable()
    {
        Application.logMessageReceived += HandleLog;
    }

    void OnDisable()
    {
        Application.logMessageReceived -= HandleLog;
    }

    private void HandleLog(string logString, string stackTrace, LogType type)
    {
        logQueue.Enqueue(logString);

        while (logQueue.Count > maxLines)
            logQueue.Dequeue();

        logText.text = string.Join("\n", logQueue.ToArray());
    }
}
