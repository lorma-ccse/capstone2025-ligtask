using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Reflection;

public class MiniGameNumberDisplay : MonoBehaviour
{
[Header("UI References")]
public TMP_Text labelText;       
public Image shadowBackground;  

private void Start()
{
    UpdateLabel();
}

public void UpdateLabel()
{
    if (labelText == null)
    {
        Debug.LogError("[MiniGameNumberDisplay] No TMP Text assigned!");
        return;
    }

    string disaster = SceneTracker.CurrentDisaster;
    string difficulty = SceneTracker.CurrentDifficulty;
    string currentScene = SceneManager.GetActiveScene().name;

    if (currentScene.ToLower().Contains("quiz"))
    {
        labelText.gameObject.SetActive(false);
        if (shadowBackground != null)
            shadowBackground.gameObject.SetActive(false);
        return;
    }

    if (shadowBackground != null)
        shadowBackground.gameObject.SetActive(true);

    if (string.IsNullOrEmpty(disaster) || string.IsNullOrEmpty(difficulty))
    {
        labelText.text = "Mini-game";
        return;
    }

    string key = $"{disaster}_{difficulty}";
    var dictField = typeof(SceneTracker).GetField("miniGameSequences",
        BindingFlags.NonPublic | BindingFlags.Static);
    var dict = dictField?.GetValue(null) as Dictionary<string, string[]>;

    if (dict == null || !dict.ContainsKey(key))
    {
        labelText.text = "Mini-game";
        return;
    }

    string[] miniGames = dict[key];

    int index = System.Array.IndexOf(miniGames, currentScene);

    if (index < 0)
    {
        labelText.text = "Mini-game";
        return;
    }

    labelText.text = $"Mini-game {index + 1}";
}

}
