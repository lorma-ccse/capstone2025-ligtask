using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using System.Reflection;

public class MiniGameMenu : MonoBehaviour
{
    [Header("UI References")]
    public Button[] miniGameButtons; 

    private void Start()
    {
        SetupMenu();
    }

    public void SetupMenu()
    {
        string disaster = SceneTracker.CurrentDisaster;
        string difficulty = SceneTracker.CurrentDifficulty;

        if (string.IsNullOrEmpty(disaster) || string.IsNullOrEmpty(difficulty))
        {
            Debug.LogError("[MiniGameMenu] No current disaster/difficulty found!");
            return;
        }

        string currentScene = SceneManager.GetActiveScene().name;
        bool isQuizScene = currentScene.ToLower().Contains("quiz");

        string key = $"{disaster}_{difficulty}";
        var dictField = typeof(SceneTracker).GetField("miniGameSequences",
            BindingFlags.NonPublic | BindingFlags.Static);
        var dict = dictField?.GetValue(null) as Dictionary<string, string[]>;

        if (dict == null || !dict.ContainsKey(key))
        {
            Debug.LogError("[MiniGameMenu] No mini-games found for " + key);
            return;
        }

        string[] miniGames = dict[key];
        var progressList = DBManager.GetMiniGameProgress(disaster, difficulty);

        int nonQuizCount = miniGames.Count(scene => !scene.ToLower().Contains("quiz"));

        int buttonIndex = 0;

        Button restartButton = miniGameButtons[buttonIndex];
        restartButton.gameObject.SetActive(true);

        TMP_Text restartLabel = restartButton.GetComponentInChildren<TMP_Text>();
        if (restartLabel != null)
            restartLabel.text = isQuizScene ? "Restart Quiz" : "Restart";

        restartButton.onClick.RemoveAllListeners();
        restartButton.onClick.AddListener(() => SceneManager.LoadScene(currentScene));
        restartButton.interactable = true;

        buttonIndex++;

        if (isQuizScene)
        {
            for (; buttonIndex < miniGameButtons.Length; buttonIndex++)
                miniGameButtons[buttonIndex].gameObject.SetActive(false);

            return;
        }

        int shownButtons = 0;
        for (int i = 0; i < miniGames.Length; i++)
        {
            string targetScene = miniGames[i];

            if (targetScene == currentScene)
                continue;

            if (targetScene.ToLower().Contains("quiz"))
                continue;

            if (buttonIndex >= miniGameButtons.Length || shownButtons >= nonQuizCount)
                break;

            Button miniButton = miniGameButtons[buttonIndex];
            miniButton.gameObject.SetActive(true);

            int sceneIndex = i;
            string capturedTarget = targetScene;

            TMP_Text label = miniButton.GetComponentInChildren<TMP_Text>();
            if (label != null)
                label.text = $"Mini-game {sceneIndex + 1}";

            bool interactable = sceneIndex == 0 ||
                                progressList.Any(p => p.MiniGameIndex == sceneIndex && p.Passed);

            miniButton.interactable = interactable;

            if (label != null)
            {
                Color c = label.color;
                c.a = interactable ? 1f : 0.5f;
                label.color = c;
            }

            miniButton.onClick.RemoveAllListeners();
            miniButton.onClick.AddListener(() =>
            {
                SceneTracker.SetCurrentMiniGame(disaster, difficulty, capturedTarget);
                SceneManager.LoadScene(capturedTarget);
            });

            buttonIndex++;
            shownButtons++;
        }

        for (; buttonIndex < miniGameButtons.Length; buttonIndex++)
            miniGameButtons[buttonIndex].gameObject.SetActive(false);
    }
}
