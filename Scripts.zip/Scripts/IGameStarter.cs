using UnityEngine;

public interface IGameStarter
{
    void StartGame();

}
