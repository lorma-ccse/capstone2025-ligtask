using UnityEngine;

public static class GameResults
{
    public static int Score;      
    public static int MaxScore;   

    public static bool Passed;   
    public static string DisasterName;
    public static int MiniGameIndex;
    public static string Difficulty;
}
