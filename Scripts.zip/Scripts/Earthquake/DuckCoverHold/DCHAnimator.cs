using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class DCHAnimator : MonoBehaviour
{
    [Header("References")]
    public Image characterImage;
    public Sprite standFrame;
    public Sprite duckFrame;
    public Sprite coverFrame;
    public Sprite holdFrame;
    public Sprite[] runFrames;
    public float runFrameRate = 0.1f;
    [Range(0.5f, 1f)]
    public float runScaleMultiplier = 0.9f;

    [HideInInspector]
    public float startX;

    private bool isRunning = false;
    private bool hasDucked = false;
    private bool hasCovered = false;
    private Coroutine runCoroutine;
    private Vector3 originalScale;

    void Start()
    {
        startX = Input.mousePosition.x;

        if (characterImage != null && standFrame != null)
        {
            characterImage.sprite = standFrame;
            originalScale = characterImage.rectTransform.localScale;
        }
    }

    public bool IsRunning => isRunning;

    public void Duck()
    {
        if (isRunning || hasDucked) return;

        if (characterImage != null && duckFrame != null)
        {
            characterImage.sprite = duckFrame;
            hasDucked = true;
        }
    }

    public void Cover()
    {
        if (isRunning || !hasDucked || hasCovered) return;

        if (characterImage != null && coverFrame != null)
        {
            characterImage.sprite = coverFrame;
            hasCovered = true;
        }
    }

    public void Hold(bool holding)
    {
        if (isRunning || !hasCovered) return;

        if (characterImage != null)
        {
            characterImage.sprite = holding ? holdFrame : coverFrame;
        }
    }

    public void Run()
    {
        if (!isRunning)
        {
            if (runCoroutine != null) StopCoroutine(runCoroutine);
            runCoroutine = StartCoroutine(RunAnimationLoop());
        }
    }

    private IEnumerator RunAnimationLoop()
    {
        if (characterImage != null && standFrame != null)
            characterImage.sprite = standFrame;

        if (characterImage != null)
            characterImage.rectTransform.localScale = originalScale * runScaleMultiplier;

        isRunning = true;
        int index = 0;

        while (isRunning)
        {
            if (characterImage != null && runFrames.Length > 0)
            {
                characterImage.sprite = runFrames[index];
                index = (index + 1) % runFrames.Length;
            }
            yield return new WaitForSeconds(runFrameRate);
        }

        if (characterImage != null && standFrame != null)
        {
            characterImage.sprite = standFrame;
            characterImage.rectTransform.localScale = originalScale;
        }

        ResetDuckCover();
    }

    public void StopRun()
    {
        isRunning = false;
    }

    public void ResetDuckCover()
    {
        hasDucked = false;
        hasCovered = false;

        if (characterImage != null && standFrame != null)
            characterImage.sprite = standFrame;
    }
}
