using UnityEngine;

[System.Serializable]
public class Questions
{
    [TextArea] 
    public string questionText; 
    public string[] options;    
    public int correctAnswerIndex; 
}
